<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">

    <!-- Viewport -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />

    <!-- Browser compatibility -->
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />

    <!-- Primary SEO -->
    <title>
      IFLEON - Infinite Logical Elements of Network | AI, DevOps & IT Consulting
    </title>
    <meta
      name="description"
      content="IFLEON delivers innovative AI, DevOps, and IT consulting solutions including cloud migration, cybersecurity, digital transformation, and tech support across India."
    />
    <meta
      name="keywords"
      content="AI consulting Nellore, DevOps services India, cloud services, cybersecurity, digital transformation, AWS, Azure, machine learning"
    />

    <!-- SEO / Crawlers -->
    <meta name="robots" content="index, follow" />
    <meta name="googlebot" content="index, follow" />

    <!-- Security / Privacy -->
    <meta name="referrer" content="strict-origin-when-cross-origin" />

    <!-- Font Awesome (unchanged) -->
    <link
      rel="stylesheet"
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css"
      integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA=="
      crossorigin="anonymous"
      referrerpolicy="no-referrer"
    />
    <script
  defer
  data-domain="ifleon.com"
  src="https://plausible.io/js/script.js"
></script>

    <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
